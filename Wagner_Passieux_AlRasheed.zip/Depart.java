
public class Depart extends Case {

    public Depart(){
        setNom("depart");
    }

    @Override
    public void tombeSurCase(Joueur joueur) {
    }
}
