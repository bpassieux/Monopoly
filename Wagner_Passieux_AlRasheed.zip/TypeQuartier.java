
public enum TypeQuartier {
    Orange,
    Bleu,
    BleuClair,
    Vert,
    Rouge,
    Jaune,
    Marron,
    Rose,
    Gare,
    Service;
}
